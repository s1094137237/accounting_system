class AccountSubject < ApplicationRecord
  # 資料表名稱是 account_subjects，Rails 預設會對應
  # 如果你用的是 Rails 5+ 且有設定資料庫連線，這樣就可以讀寫了
end