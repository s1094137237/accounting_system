module Printable
  extend ActiveSupport::Concern

  def print_123
    123
  end
end